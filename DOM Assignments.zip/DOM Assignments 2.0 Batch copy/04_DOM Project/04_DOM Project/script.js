const barb = document.querySelector(".barb");
barb.style.backgroundColor ="#ec9b3b";
const archer = document.querySelector(".arch");
archer.style.backgroundColor="#EF6A97";
const gian = document.querySelector(".gian");
gian.style.backgroundColor = "#E39D4C";
const gobl = document.querySelector(".gobl");
gobl.style.backgroundColor = "#8CC33E";
const wiz = document.querySelector(".wiz");
wiz.style.backgroundColor = "#4EACFF";

// const red =  document.querySelectorAll(".stat");
// red.style.color="red";
const white = document.querySelectorAll(".one-third");
// white.style.color="white";
white.forEach((col)=>{
    col.style.color="white";
});
